# Flow INR — Android APK project

This wraps the supplied `index.html` in a simple Android WebView app. GitHub Actions builds a **debug APK** and publishes it as a downloadable workflow artifact.

## Build an APK using GitHub (phone-friendly route)

1. Extract this ZIP on your phone or computer. The repository root must contain `settings.gradle`, `build.gradle`, `app/`, and `.github/`.
2. On GitHub, create a new repository named `flow-inr-android`.
3. Upload the **contents** of this folder to the repository root (not just the ZIP file). Ensure `.github/workflows/build-apk.yml` is included. If the GitHub app doesn't offer folder upload, open `github.com` in Chrome and use the browser's repository upload interface, or upload from a computer.
4. Commit the files to the `main` branch.
5. Open the repository on GitHub → **Actions** → **Build Flow INR APK**. If it hasn't started automatically, select **Run workflow**.
6. Open the completed run and download the artifact named `Flow-INR-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`.
7. Transfer `app-debug.apk` to your Android phone and open it to install. Android may ask you to allow installs from that file app/browser; only enable this for a source you trust.

## Important notes

- This is a **debug APK**, suitable for testing and personal installation, not a release-signed Play Store package.
- The app uses the original HTML. Tailwind CSS, Google Fonts, and Lucide are loaded from external CDNs, so those styling/icons require internet access. The ledger itself stores data in WebView local storage; clearing app data or uninstalling can erase it. Export JSON from the app before doing either.
- This wrapper does not add a native database, cloud sync, or a custom launcher icon.
- For public distribution, configure a release signing key securely in GitHub Actions and build a release APK/AAB. Never commit a keystore or passwords to the repository.
